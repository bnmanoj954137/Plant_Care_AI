# PlantCare AI

Plant disease detection (pretrained MobileNetV2) with treatment and prevention recommendations.

## Folder layout
```
PlantCareAI/
├── app.py
├── requirements.txt
├── backend/
│   ├── __init__.py
│   ├── predictor.py     # runs the model
│   ├── treatment.py     # treatment database + matching
│   └── history.py       # saves detections
└── data/
    ├── treatments.csv   # your editable treatment database (optional)
    └── history.json     # created automatically
```

## Run (VS Code terminal, Python 3.12)
```
pip install -r requirements.txt
python app.py
```
The first run downloads the model from Hugging Face (internet needed once).

## Adding your own database
Edit `data/treatments.csv`. Columns:

| column | meaning |
|---|---|
| plant | plant name as in the model label, e.g. `tomato` |
| disease_key | disease words, e.g. `early blight` (use `healthy` for healthy leaves) |
| name | title shown to the user |
| about | one-line description |
| treatment | steps separated by `;` |
| prevention | prevention tip |

A row replaces the built-in entry with the same plant + disease_key, and a new row adds a new one.
Run `python -m backend.treatment` to regenerate the CSV from the built-in data.
Restart is not needed; the file is read on every detection.

## Training on your image dataset (PlantVillage)
1. Download PlantVillage from Kaggle and unzip it. Use the `color` folder (one sub-folder per class).
2. Split it into train/val/test:
   `python prepare_dataset.py --source "C:/path/to/color" --out dataset`
3. Quick test (a few images, 1 epoch):
   `python train.py --data dataset --out models/test_model --epochs 1 --limit 20`
4. Full training (use a GPU, e.g. Google Colab):
   `python train.py --data dataset --out models/my_model --epochs 5`
5. In `app.py` set `MODEL_ID = "models/my_model"` and run `python app.py`.

Class folder names (e.g. `Tomato___Early_blight`) must match the treatment table, and any new class needs a row in `data/treatments.csv`.
