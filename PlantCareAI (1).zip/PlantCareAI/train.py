"""Fine-tune the plant-disease classifier on your own dataset.

Usage (after prepare_dataset.py):
    python train.py --data dataset --out models/my_model --epochs 5

Quick smoke test (a few images per class, 1 epoch):
    python train.py --data dataset --out models/test_model --epochs 1 --limit 20

Then set MODEL_ID = "models/my_model" in app.py.
"""
import argparse
import random
from pathlib import Path

import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from transformers import AutoImageProcessor, AutoModelForImageClassification

BASE_MODEL = "LourivalGontijo/plantvillage-mobilenetv2"
IMG_EXT = {".jpg", ".jpeg", ".png"}


class FolderDataset(Dataset):
    def __init__(self, root: Path, class_names, processor, train: bool, limit=None):
        self.processor, self.train = processor, train
        self.items = []
        for idx, name in enumerate(class_names):
            folder = root / name
            if not folder.is_dir():
                continue
            files = sorted(f for f in folder.iterdir() if f.suffix.lower() in IMG_EXT)
            if limit:
                files = files[:limit]
            self.items += [(f, idx) for f in files]

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        path, label = self.items[i]
        img = Image.open(path).convert("RGB")
        if self.train:  # light augmentation
            if random.random() < 0.5:
                img = img.transpose(Image.FLIP_LEFT_RIGHT)
            img = img.rotate(random.uniform(-20, 20))
        pixels = self.processor(images=img, return_tensors="pt")["pixel_values"][0]
        return pixels, label


def evaluate(model, loader, device):
    model.eval()
    correct = total = 0
    with torch.no_grad():
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            pred = model(pixel_values=x).logits.argmax(dim=-1)
            correct += (pred == y).sum().item()
            total += y.numel()
    return correct / max(total, 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="dataset", help="Folder with train/ val/ test/")
    ap.add_argument("--out", default="models/my_model")
    ap.add_argument("--base", default=BASE_MODEL, help="Model to start from")
    ap.add_argument("--epochs", type=int, default=5)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--workers", type=int, default=0, help="Keep 0 on Windows")
    ap.add_argument("--limit", type=int, default=None, help="Max images per class (for quick tests)")
    args = ap.parse_args()

    data = Path(args.data)
    for split in ("train", "val"):
        if not (data / split).is_dir():
            raise SystemExit(f"Missing folder: {data / split}. Run prepare_dataset.py first.")

    class_names = sorted(d.name for d in (data / "train").iterdir() if d.is_dir())
    id2label = {i: n for i, n in enumerate(class_names)}
    label2id = {n: i for i, n in id2label.items()}
    print(f"{len(class_names)} classes found")

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Training on: {device}" + ("  (slow; consider Google Colab GPU)" if device == "cpu" else ""))

    processor = AutoImageProcessor.from_pretrained(args.base)
    model = AutoModelForImageClassification.from_pretrained(
        args.base, num_labels=len(class_names), id2label=id2label, label2id=label2id,
        ignore_mismatched_sizes=True,
    ).to(device)

    train_ds = FolderDataset(data / "train", class_names, processor, True, args.limit)
    val_ds = FolderDataset(data / "val", class_names, processor, False, args.limit)
    train_dl = DataLoader(train_ds, batch_size=args.batch, shuffle=True, num_workers=args.workers)
    val_dl = DataLoader(val_ds, batch_size=args.batch, num_workers=args.workers)
    print(f"train images: {len(train_ds)} | val images: {len(val_ds)}")

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr)
    best, out = 0.0, Path(args.out)
    for epoch in range(1, args.epochs + 1):
        model.train()
        running = 0.0
        for step, (x, y) in enumerate(train_dl, 1):
            x, y = x.to(device), y.to(device)
            loss = model(pixel_values=x, labels=y).loss
            opt.zero_grad()
            loss.backward()
            opt.step()
            running += loss.item()
            if step % 50 == 0:
                print(f"  epoch {epoch} step {step}/{len(train_dl)} loss {running / step:.4f}")
        acc = evaluate(model, val_dl, device)
        print(f"Epoch {epoch}/{args.epochs}  train loss {running / len(train_dl):.4f}  val accuracy {acc:.2%}")
        if acc >= best:
            best = acc
            out.mkdir(parents=True, exist_ok=True)
            model.save_pretrained(out)
            processor.save_pretrained(out)
            print(f"  saved best model to {out}")

    if (data / "test").is_dir():
        best_model = AutoModelForImageClassification.from_pretrained(out).to(device)
        test_ds = FolderDataset(data / "test", class_names, processor, False, args.limit)
        test_dl = DataLoader(test_ds, batch_size=args.batch, num_workers=args.workers)
        print(f"Test accuracy (best model): {evaluate(best_model, test_dl, device):.2%}")

    print(f'\nDone. In app.py set: MODEL_ID = "{out.as_posix()}"')


if __name__ == "__main__":
    main()
