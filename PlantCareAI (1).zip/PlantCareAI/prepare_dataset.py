"""Split a class-per-folder image dataset (e.g. PlantVillage 'color') into train/val/test.

Usage:
    python prepare_dataset.py --source "C:/path/to/plantvillage dataset/color" --out dataset

Result:
    dataset/train/<class>/*.jpg   (80%)
    dataset/val/<class>/*.jpg     (10%)
    dataset/test/<class>/*.jpg    (10%)
"""
import argparse
import random
import shutil
from pathlib import Path

IMG_EXT = {".jpg", ".jpeg", ".png"}


def find_class_root(source: Path) -> Path:
    """Descend through single-folder wrappers until we reach the folder that holds the class folders."""
    current = source
    for _ in range(4):
        subdirs = [d for d in current.iterdir() if d.is_dir()]
        has_images = any(f.suffix.lower() in IMG_EXT for f in current.iterdir() if f.is_file())
        if has_images or len(subdirs) != 1:
            return current
        current = subdirs[0]
    return current


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True, help="Folder containing one sub-folder per class")
    ap.add_argument("--out", default="dataset", help="Output folder (default: dataset)")
    ap.add_argument("--val", type=float, default=0.1)
    ap.add_argument("--test", type=float, default=0.1)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    source = Path(args.source)
    if not source.is_dir():
        raise SystemExit(f"Source folder not found: {source}")
    out = Path(args.out)
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f"Output folder '{out}' is not empty. Delete it or choose another --out.")

    root = find_class_root(source)
    classes = sorted(d for d in root.iterdir() if d.is_dir())
    if not classes:
        raise SystemExit(f"No class folders found in {root}")

    rng = random.Random(args.seed)
    totals = {"train": 0, "val": 0, "test": 0}
    for cls in classes:
        files = sorted(f for f in cls.iterdir() if f.is_file() and f.suffix.lower() in IMG_EXT)
        if not files:
            continue
        rng.shuffle(files)
        n_val = int(len(files) * args.val)
        n_test = int(len(files) * args.test)
        splits = {
            "val": files[:n_val],
            "test": files[n_val:n_val + n_test],
            "train": files[n_val + n_test:],
        }
        for split, items in splits.items():
            dest = out / split / cls.name
            dest.mkdir(parents=True, exist_ok=True)
            for f in items:
                shutil.copy2(f, dest / f.name)
            totals[split] += len(items)
        print(f"{cls.name}: {len(files)} images")

    print(f"\nDone. train={totals['train']} val={totals['val']} test={totals['test']} -> {out.resolve()}")


if __name__ == "__main__":
    main()
