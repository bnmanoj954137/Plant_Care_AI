"""Local detection history stored in data/history.json."""
import json
from pathlib import Path

HISTORY_FILE = Path(__file__).resolve().parent.parent / "data" / "history.json"


def _read():
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def save_record(record: dict):
    HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    data = _read()
    data.append({
        "date": record.get("date", ""),
        "label": record.get("label", ""),
        "confidence": record.get("confidence", ""),
    })
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def load_history():
    """Rows for the Gradio table, newest first: [date, prediction, confidence]."""
    rows = [[r.get("date", ""), r.get("label", ""), r.get("confidence", "")] for r in _read()]
    return rows[::-1]
