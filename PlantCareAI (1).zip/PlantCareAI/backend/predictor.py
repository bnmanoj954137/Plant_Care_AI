"""Leaf image classification using a pretrained Hugging Face model."""
from functools import lru_cache

from PIL import Image


@lru_cache(maxsize=2)
def _get_classifier(model_id: str):
    # Imported here so the app can start (and show a clear error) even if
    # transformers/torch are missing.
    from transformers import pipeline
    return pipeline("image-classification", model=model_id)


def predict_leaf(image, model_id: str, top_k: int = 3):
    """Return a list of {"label": str, "score": float}, best first."""
    if image is None:
        return []
    if not isinstance(image, Image.Image):
        image = Image.fromarray(image)
    image = image.convert("RGB")
    classifier = _get_classifier(model_id)
    results = classifier(image, top_k=top_k)
    return [{"label": str(r["label"]), "score": float(r["score"])} for r in results]
