"""Treatment and care recommendations for the 38 PlantVillage classes.

The built-in knowledge base below is used by default. To add or override
entries with your own database, edit data/treatments.csv (see README.md).
"""
import csv
import re
from pathlib import Path

CSV_FILE = Path(__file__).resolve().parent.parent / "data" / "treatments.csv"

# (plant, disease_key, display_disease, about, [treatment steps], prevention)
# disease_key "healthy" = healthy leaf.
_BUILTIN = [
    # ---------------- Apple ----------------
    ("apple", "scab", "Apple scab",
     "Fungal disease (Venturia inaequalis) causing olive-green to dark scabby spots on leaves and fruit.",
     ["Rake and destroy fallen leaves; they carry the fungus through winter.",
      "Prune to open the canopy so leaves dry quickly.",
      "Apply a protectant fungicide (captan, mancozeb or sulfur, per label) from green-tip through petal fall.",
      "Remove and discard badly infected fruit and shoots."],
     "Plant scab-resistant varieties and avoid overhead irrigation."),
    ("apple", "black rot", "Apple black rot",
     "Fungal disease (Botryosphaeria obtusa) causing frog-eye leaf spots, fruit rot and cankers.",
     ["Prune out dead wood, cankers and mummified fruit and remove them from the orchard.",
      "Apply captan or a labelled fungicide from bloom through summer.",
      "Sterilise pruning tools between cuts.",
      "Keep trees well watered and fertilised to reduce stress."],
     "Sanitation is the key: never leave mummified fruit or dead branches on or under the tree."),
    ("apple", "cedar apple rust", "Cedar apple rust",
     "Fungal disease needing both apple and juniper/cedar; shows bright orange-yellow spots on leaves.",
     ["Remove nearby juniper/cedar galls if possible.",
      "Apply a labelled fungicide (myclobutanil or mancozeb) from pink bud through 2-3 weeks after petal fall.",
      "Remove heavily infected leaves."],
     "Choose rust-resistant apple varieties and keep junipers away from the orchard."),
    ("apple", "healthy", "Healthy apple leaf", "", [], "Prune annually, mulch, and monitor leaves weekly."),

    # ---------------- Blueberry ----------------
    ("blueberry", "healthy", "Healthy blueberry leaf", "", [],
     "Keep soil acidic (pH 4.5-5.5), mulch with pine bark and water evenly."),

    # ---------------- Cherry ----------------
    ("cherry", "powdery mildew", "Cherry powdery mildew",
     "Fungal disease producing white powdery patches and curled leaves.",
     ["Prune to improve air flow and remove infected shoots.",
      "Apply sulfur, potassium bicarbonate or a labelled fungicide at first sign, repeating every 7-14 days.",
      "Avoid excess nitrogen fertiliser, which promotes susceptible new growth."],
     "Plant in sun with good spacing; water at the base of the tree."),
    ("cherry", "healthy", "Healthy cherry leaf", "", [], "Prune in dry weather and keep the canopy open."),

    # ---------------- Corn ----------------
    ("corn", "gray leaf spot", "Corn gray leaf spot",
     "Fungal disease (Cercospora zeae-maydis) with rectangular tan-grey lesions between veins.",
     ["Apply a foliar fungicide (strobilurin/triazole, per label) at early tassel if disease is spreading.",
      "Rotate away from corn for 1-2 years and bury residue by tillage.",
      "Avoid dense planting and improve drainage."],
     "Use resistant hybrids and rotate crops."),
    ("corn", "common rust", "Corn common rust",
     "Fungal disease (Puccinia sorghi) with small brick-red pustules on both leaf surfaces.",
     ["Spray a labelled fungicide if pustules appear before tasseling on susceptible hybrids.",
      "Scout fields weekly during cool, humid weather.",
      "Remove volunteer corn and weeds nearby."],
     "Plant resistant hybrids and plant early."),
    ("corn", "northern leaf blight", "Corn northern leaf blight",
     "Fungal disease (Exserohilum turcicum) with long grey-green cigar-shaped lesions.",
     ["Apply a labelled foliar fungicide at tasseling if lesions reach the ear leaf.",
      "Bury or remove crop residue after harvest.",
      "Rotate with a non-host crop for at least 1 year."],
     "Use resistant hybrids and avoid continuous corn."),
    ("corn", "healthy", "Healthy corn leaf", "", [], "Maintain balanced fertiliser and rotate crops yearly."),

    # ---------------- Grape ----------------
    ("grape", "black rot", "Grape black rot",
     "Fungal disease (Guignardia bidwellii) with brown leaf spots and shrivelled black fruit.",
     ["Remove mummified berries and infected leaves/canes; do not compost them.",
      "Apply mancozeb, myclobutanil or captan (per label) from early shoot growth through fruit set.",
      "Prune and train vines for good airflow and sun penetration."],
     "Sanitation in winter plus a spray programme at bud break gives best control."),
    ("grape", "esca", "Grape esca (black measles)",
     "Chronic wood-rot disease causing tiger-stripe leaves and spotted berries.",
     ["Prune out dead or diseased wood in dry weather and seal large wounds.",
      "Mark affected vines and remove severely affected ones.",
      "Disinfect pruning tools; there is no reliable chemical cure."],
     "Avoid large pruning wounds and prune late in the dormant season."),
    ("grape", "leaf blight", "Grape leaf blight (Isariopsis leaf spot)",
     "Fungal leaf spot causing dark brown irregular patches and early leaf fall.",
     ["Remove infected leaves and fallen debris.",
      "Apply a copper-based or mancozeb fungicide per label.",
      "Thin the canopy for airflow."],
     "Water at the base and avoid overcrowded vines."),
    ("grape", "healthy", "Healthy grape leaf", "", [], "Prune for airflow and monitor weekly in wet weather."),

    # ---------------- Orange ----------------
    ("orange", "haunglongbing", "Citrus greening (Huanglongbing)",
     "Serious bacterial disease spread by the Asian citrus psyllid; causes blotchy yellow leaves and bitter, lopsided fruit.",
     ["Report suspected cases to your local agriculture office; there is no cure.",
      "Remove and destroy infected trees to protect healthy ones.",
      "Control psyllids with labelled insecticides or horticultural oil.",
      "Give remaining trees balanced nutrition to prolong productivity."],
     "Buy certified disease-free plants and monitor for psyllids regularly."),

    # ---------------- Peach ----------------
    ("peach", "bacterial spot", "Peach bacterial spot",
     "Bacterial disease (Xanthomonas) causing small angular dark leaf spots, shot-holes and fruit pitting.",
     ["Apply copper-based bactericide early in the season and at petal fall (per label).",
      "Prune to improve airflow and avoid overhead watering.",
      "Avoid excess nitrogen, which makes trees more susceptible."],
     "Plant tolerant varieties and keep the canopy open."),
    ("peach", "healthy", "Healthy peach leaf", "", [], "Prune yearly and protect against winter frost."),

    # ---------------- Pepper ----------------
    ("pepper bell", "bacterial spot", "Pepper bacterial spot",
     "Bacterial disease causing water-soaked spots that turn brown, with leaf drop and rough fruit spots.",
     ["Remove and destroy badly infected plants.",
      "Spray copper-based bactericide (per label) every 7-10 days in wet weather.",
      "Do not work in the field when plants are wet.",
      "Use certified disease-free seed and rotate crops for 2-3 years."],
     "Drip irrigation and clean tools keep bacteria from spreading."),
    ("pepper bell", "healthy", "Healthy pepper leaf", "", [], "Water at the base and feed regularly."),

    # ---------------- Potato ----------------
    ("potato", "early blight", "Potato early blight",
     "Fungal disease (Alternaria solani) with dark target-like spots, mostly on older leaves.",
     ["Remove infected lower leaves.",
      "Apply chlorothalonil, mancozeb or copper fungicide (per label) every 7-10 days.",
      "Keep plants well fed; stressed plants are more susceptible.",
      "Rotate with non-solanaceous crops for 2-3 years."],
     "Use certified seed potatoes and mulch to reduce soil splash."),
    ("potato", "late blight", "Potato late blight",
     "Fast-spreading disease (Phytophthora infestans) with water-soaked dark patches and white mold underneath.",
     ["Act immediately: remove and destroy infected plants (do not compost).",
      "Apply a protectant fungicide (chlorothalonil, mancozeb or systemic, per label) before and during wet weather.",
      "Hill up soil around tubers and delay harvest until foliage is dead to protect tubers.",
      "Inspect and discard any blemished tubers before storage."],
     "Plant resistant varieties and avoid overhead irrigation. Destroy volunteer potatoes."),
    ("potato", "healthy", "Healthy potato leaf", "", [], "Hill soil regularly and rotate crops."),

    # ---------------- Raspberry / Soybean ----------------
    ("raspberry", "healthy", "Healthy raspberry leaf", "", [], "Prune old canes after fruiting and keep rows open."),
    ("soybean", "healthy", "Healthy soybean leaf", "", [], "Rotate with cereals and scout fields regularly."),

    # ---------------- Squash ----------------
    ("squash", "powdery mildew", "Squash powdery mildew",
     "Fungal disease producing white powdery coating that dries and yellows leaves.",
     ["Remove severely affected leaves.",
      "Spray neem oil, potassium bicarbonate or sulfur (per label) every 7 days.",
      "A mix of 1 tbsp baking soda + 1/2 tsp liquid soap per litre of water can slow mild cases.",
      "Water the soil, not the leaves."],
     "Choose resistant varieties and give plants space for airflow."),

    # ---------------- Strawberry ----------------
    ("strawberry", "leaf scorch", "Strawberry leaf scorch",
     "Fungal disease (Diplocarpon earlianum) with purple-brown spots that merge so leaves look scorched.",
     ["Remove infected leaves after harvest and renovate the bed.",
      "Apply a labelled fungicide (captan or myclobutanil) at first sign.",
      "Water in the morning at the base of plants."],
     "Use certified plants, space well and renew beds every 2-3 years."),
    ("strawberry", "healthy", "Healthy strawberry leaf", "", [], "Mulch with straw and remove old leaves each season."),

    # ---------------- Tomato ----------------
    ("tomato", "bacterial spot", "Tomato bacterial spot",
     "Bacterial disease causing small dark greasy spots on leaves and rough scabby fruit spots.",
     ["Remove infected plants/leaves and discard them.",
      "Spray copper bactericide (per label) every 7-10 days in warm, wet weather.",
      "Avoid handling wet plants; disinfect tools.",
      "Rotate away from tomatoes and peppers for 2-3 years."],
     "Use clean seed and drip irrigation."),
    ("tomato", "early blight", "Tomato early blight",
     "Fungal disease (Alternaria solani) with brown target-like rings and yellowing around spots, starting on lower leaves.",
     ["Remove infected lower leaves and mulch the soil to stop splash.",
      "Apply chlorothalonil, mancozeb or copper fungicide (per label) every 7-10 days.",
      "Stake and prune plants to improve airflow.",
      "Rotate crops every 2-3 years."],
     "Water at the base in the morning and feed regularly."),
    ("tomato", "late blight", "Tomato late blight",
     "Aggressive disease (Phytophthora infestans) with greasy grey-brown patches and white mold in humid weather.",
     ["Remove and destroy infected plants immediately; do not compost.",
      "Apply a protectant fungicide (chlorothalonil, mancozeb or copper, per label) to healthy plants nearby.",
      "Improve airflow and avoid wetting leaves.",
      "Do not plant tomatoes/potatoes in the same spot next season."],
     "Plant resistant varieties and watch weather forecasts for cool, wet spells."),
    ("tomato", "leaf mold", "Tomato leaf mold",
     "Fungal disease (Passalora fulva) with pale-yellow spots on top and olive-grey mold underneath, common in humid greenhouses.",
     ["Reduce humidity and improve ventilation.",
      "Remove infected leaves.",
      "Apply a labelled fungicide (chlorothalonil or copper) if it spreads.",
      "Avoid overhead watering."],
     "Space plants, prune lower leaves and use resistant varieties."),
    ("tomato", "septoria", "Tomato Septoria leaf spot",
     "Fungal disease with many small round spots with dark borders and grey centres, mostly on lower leaves.",
     ["Remove infected leaves right away.",
      "Spray chlorothalonil, mancozeb or copper fungicide (per label) every 7-10 days.",
      "Mulch to prevent soil splash and stake plants.",
      "Rotate crops for 3 years."],
     "Clean up plant debris at season end and avoid overhead watering."),
    ("tomato", "spider mite", "Tomato spider mites",
     "Tiny sap-sucking mites causing speckled yellow leaves and fine webbing, worst in hot, dry weather.",
     ["Spray plants (especially leaf undersides) with strong water to dislodge mites.",
      "Apply insecticidal soap or neem oil every 4-5 days for 2-3 weeks.",
      "Use a labelled miticide for heavy infestations.",
      "Keep plants well watered; dust and drought stress favour mites."],
     "Inspect leaf undersides weekly and avoid broad-spectrum insecticides that kill natural predators."),
    ("tomato", "target spot", "Tomato target spot",
     "Fungal disease (Corynespora cassiicola) with brown spots showing concentric rings.",
     ["Remove infected leaves and avoid overhead irrigation.",
      "Apply chlorothalonil or a labelled fungicide every 7-14 days.",
      "Improve airflow by staking and pruning."],
     "Rotate crops and remove old plant debris."),
    ("tomato", "yellow leaf curl", "Tomato yellow leaf curl virus",
     "Virus spread by whiteflies; causes small, upward-curled, yellow leaves and stunted plants. No cure.",
     ["Remove and destroy infected plants to stop spread.",
      "Control whiteflies with yellow sticky traps, neem oil or labelled insecticides.",
      "Cover seedlings with fine insect netting."],
     "Plant resistant varieties and keep weeds (virus hosts) down."),
    ("tomato", "mosaic virus", "Tomato mosaic virus",
     "Virus causing mottled light and dark green leaves, distortion and stunting. No cure.",
     ["Remove and destroy infected plants (do not compost).",
      "Wash hands with soap and disinfect tools; the virus spreads by touch and sap.",
      "Do not smoke around plants (tobacco can carry the virus)."],
     "Use certified virus-free seed and resistant varieties."),
    ("tomato", "healthy", "Healthy tomato leaf", "", [], "Water at the base, stake plants and feed every 2-3 weeks."),
]

GENERIC_HEALTHY = [
    "No disease detected. Keep up regular care.",
    "Water at the soil level, ideally in the morning.",
    "Give the plant adequate sunlight and space for airflow.",
    "Feed with balanced fertiliser during the growing season.",
    "Inspect leaves weekly for early signs of pests or disease.",
]

DISCLAIMER = ("*General educational guidance only. Always follow the product label and local "
              "agricultural regulations, and confirm serious problems with a local expert.*")


def _norm(text: str) -> str:
    """Lowercase and collapse separators so 'Tomato___Early_blight' == 'tomato early blight'."""
    text = re.sub(r"[^a-z0-9]+", " ", str(text).lower())
    return text.strip()


def _load_entries():
    """Built-in entries, replaced/extended by data/treatments.csv when present."""
    entries = {}
    for plant, key, name, about, steps, prevention in _BUILTIN:
        entries[(_norm(plant), _norm(key))] = {
            "plant": _norm(plant), "key": _norm(key), "name": name,
            "about": about, "steps": list(steps), "prevention": prevention,
        }
    if CSV_FILE.exists():
        try:
            with open(CSV_FILE, "r", encoding="utf-8-sig", newline="") as f:
                for row in csv.DictReader(f):
                    plant, key = _norm(row.get("plant", "")), _norm(row.get("disease_key", ""))
                    if not plant or not key:
                        continue
                    entries[(plant, key)] = {
                        "plant": plant, "key": key,
                        "name": (row.get("name") or "").strip() or f"{plant.title()} {key}",
                        "about": (row.get("about") or "").strip(),
                        "steps": [s.strip() for s in (row.get("treatment") or "").split(";") if s.strip()],
                        "prevention": (row.get("prevention") or "").strip(),
                    }
        except Exception as exc:  # a broken CSV must never crash the app
            print(f"[treatment] Could not read {CSV_FILE}: {exc}. Using built-in data.")
    return entries


def _find(label: str):
    entries = _load_entries()
    padded = f" {_norm(label)} "
    best, best_len = None, 0
    for (plant, key), entry in entries.items():
        if f" {plant} " in padded and f" {key} " in padded:
            length = len(plant) + len(key)
            if length > best_len:
                best, best_len = entry, length
    return best


def get_treatment(label: str) -> str:
    """Markdown with disease info, treatment and prevention for a model label."""
    entry = _find(label)
    if entry is None:
        if re.fullmatch(r"label \d+", _norm(label)):
            return ("### Treatment not available\n\nThe model returned a generic class name "
                    f"(`{label}`), so the disease could not be identified by name. "
                    "Check that the model's class names are loaded correctly.\n\n" + DISCLAIMER)
        return ("### Treatment not available for this class\n\n"
                f"No entry matches `{label}`. You can add one in `data/treatments.csv`.\n\n"
                "**General advice:** isolate the plant, remove badly affected leaves, avoid wetting "
                "foliage, improve airflow and consult a local agricultural expert.\n\n" + DISCLAIMER)

    if entry["key"] == "healthy":
        steps = "\n".join(f"- {s}" for s in GENERIC_HEALTHY)
        return (f"### ✅ {entry['name']}\n\nThe leaf looks healthy.\n\n"
                f"**Care recommendations**\n{steps}\n\n**Tip:** {entry['prevention']}\n\n{DISCLAIMER}")

    steps = "\n".join(f"{i}. {s}" for i, s in enumerate(entry["steps"], 1)) or "_No steps listed._"
    about = f"{entry['about']}\n\n" if entry["about"] else ""
    return (f"### 💊 {entry['name']}\n\n{about}**Recommended treatment**\n\n{steps}\n\n"
            f"**🛡️ Prevention:** {entry['prevention']}\n\n{DISCLAIMER}")


def list_classes():
    """Sorted display names for the browse dropdown."""
    return sorted(e["name"] for e in _load_entries().values())


def get_treatment_by_name(display_name: str) -> str:
    for e in _load_entries().values():
        if e["name"] == display_name:
            return get_treatment(f"{e['plant']} {e['key']}")
    return "Select a disease from the list."


def export_csv(path=CSV_FILE):
    """Write the built-in data to a CSV you can edit."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["plant", "disease_key", "name", "about", "treatment", "prevention"])
        for plant, key, name, about, steps, prevention in _BUILTIN:
            w.writerow([plant, key, name, about, "; ".join(steps), prevention])


if __name__ == "__main__":
    export_csv()
    print(f"Wrote {CSV_FILE}")
