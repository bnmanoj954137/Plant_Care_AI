from datetime import datetime

import gradio as gr

from backend.predictor import predict_leaf
from backend.treatment import get_treatment, get_treatment_by_name, list_classes
from backend.history import save_record, load_history

APP_TITLE = "PlantCare AI"
MODEL_ID = "LourivalGontijo/plantvillage-mobilenetv2"

NO_ADVICE = "Treatment and care guidance will appear here after detection."


def pretty(label: str) -> str:
    return label.replace("___", " — ").replace("_", " ")


def run_detection(image):
    """Returns: result_md, advice_md, advice_md (treatment tab), record, top3 rows."""
    if image is None:
        return ("Please upload a clear leaf image first.", NO_ADVICE, NO_ADVICE, None, [])
    try:
        predictions = predict_leaf(image, MODEL_ID)
        if not predictions:
            return ("The model returned no predictions.", "Please try another image.",
                    NO_ADVICE, None, [])
        best = predictions[0]
        raw_label = best["label"]
        confidence = float(best["score"]) * 100
        readable = pretty(raw_label)

        result = (f"## Prediction: {readable}\n\n**Model confidence: {confidence:.2f}%**\n\n"
                  "> Confidence is the model's score, not a guarantee of diagnostic accuracy.")
        if confidence < 60:
            result += ("\n\n⚠️ **Low confidence.** Try a clearer, close-up photo of a single leaf "
                       "on a plain background.")

        top_rows = [[pretty(p["label"]), f'{float(p["score"]) * 100:.2f}%'] for p in predictions[:3]]
        advice = get_treatment(raw_label)
        record = {
            "date": datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z"),
            "label": readable,
            "confidence": f"{confidence:.2f}%",
        }
        return result, advice, advice, record, top_rows
    except Exception as exc:
        msg = f"Prediction failed: {type(exc).__name__}: {exc}"
        return msg, "Check the setup guide and try again.", NO_ADVICE, None, []


def save_latest(record):
    if not record:
        return "Run a prediction before saving.", load_history()
    try:
        save_record(record)
        return "Detection saved to local history.", load_history()
    except Exception as exc:
        return f"Could not save history: {exc}", load_history()


with gr.Blocks(title=APP_TITLE, theme=gr.themes.Soft(),
               css="footer {display: none !important;}") as demo:
    current_record = gr.State(None)
    gr.HTML("""
    <div style="padding:28px;border-radius:18px;text-align:center;
    background:linear-gradient(110deg,#14532d,#0f766e);color:white">
      <h1 style="color:white;font-size:38px;margin:0">🌱 PlantCare AI</h1>
      <p style="font-size:18px">Plant Disease Detection & Treatment Recommendation System</p>
      <p>Healthy Plants • Healthy Future</p>
    </div>
    """)

    with gr.Tabs():
        with gr.Tab("🏠 Home"):
            gr.Markdown("""
            ## Welcome to PlantCare AI
            Upload a plant-leaf photograph to receive a prediction from a
            pretrained PlantVillage MobileNetV2 image classifier, together with
            **treatment and prevention recommendations**.

            **Features**
            - AI-based image classification and top-three predictions
            - Treatment, care and prevention guidance for all 38 PlantVillage classes
            - Browse the treatment library without uploading an image
            - Local detection history saved on this computer

            **Important:** This is an educational prototype. PlantVillage images
            are mostly controlled-background images. Real-world field photos,
            mixed infections, nutrient problems and non-leaf symptoms may not
            be recognized reliably. Confirm important decisions with an
            agricultural expert.
            """)

        with gr.Tab("🔍 Disease Detection"):
            gr.Markdown("## Upload a clear plant-leaf image")
            with gr.Row():
                image_input = gr.Image(type="pil", label="Choose JPG or PNG", height=360)
                with gr.Column():
                    detect_btn = gr.Button("DETECT DISEASE", variant="primary")
                    result_output = gr.Markdown("Prediction will appear here.")
                    top_output = gr.Dataframe(headers=["Class", "Model score"],
                                              label="Top 3 predictions", interactive=False)
            gr.Markdown("## 💊 Treatment & Recommendation")
            advice_output = gr.Markdown(NO_ADVICE)
            save_btn = gr.Button("Save this detection to history")
            save_status = gr.Markdown()
            history_table = gr.Dataframe(headers=["Date", "Prediction", "Confidence"],
                                         value=load_history(), interactive=False)

        with gr.Tab("💊 Treatment Guidance"):
            gr.Markdown("## Latest detection")
            treatment_latest = gr.Markdown(NO_ADVICE)
            gr.Markdown("---\n## Browse the treatment library")
            class_dropdown = gr.Dropdown(choices=list_classes(), label="Select a plant disease")
            library_output = gr.Markdown("Choose a disease to see its treatment.")
            class_dropdown.change(get_treatment_by_name, inputs=class_dropdown,
                                  outputs=library_output)
            gr.Markdown("Guidance is general and educational. Not a chemical prescription. "
                        "Always follow product labels and local regulations.")

        with gr.Tab("📋 History"):
            gr.Markdown("Saved predictions are stored locally in `data/history.json`.")
            history_view = gr.Dataframe(headers=["Date", "Prediction", "Confidence"],
                                        value=load_history(), interactive=False)
            refresh_btn = gr.Button("Refresh history")
            refresh_btn.click(load_history, outputs=history_view)

        with gr.Tab("ℹ️ About"):
            gr.Markdown(f"""
            **Project:** Plant Disease Detection and Treatment Recommendation System

            **Language:** Python
            **Interface:** Gradio
            **Model framework:** Hugging Face Transformers / PyTorch
            **Model ID:** `{MODEL_ID}`
            **Dataset reference:** PlantVillage (Kaggle)
            **Treatment data:** built-in knowledge base + optional `data/treatments.csv`

            This version uses a pretrained model. It does not train a new model from the dataset.
            """)

    # Wire events after all components exist
    detect_btn.click(run_detection, inputs=image_input,
                     outputs=[result_output, advice_output, treatment_latest,
                              current_record, top_output])
    save_btn.click(save_latest, inputs=current_record, outputs=[save_status, history_table])


if __name__ == "__main__":
    demo.launch(inbrowser=True, show_api=False)
